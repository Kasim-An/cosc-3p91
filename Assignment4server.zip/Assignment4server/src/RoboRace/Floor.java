package RoboRace;

public class Floor implements Tile {
	
	public void effect(EventCounter counter, EventList events, Robot robot, Board board) {
	}
	
	public String toXMLString() {
		return "<floor/>";
	}
	
}
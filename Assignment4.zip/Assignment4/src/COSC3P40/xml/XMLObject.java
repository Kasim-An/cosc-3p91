package COSC3P40.xml;

public interface XMLObject {
	
	public String toXMLString();
	
}
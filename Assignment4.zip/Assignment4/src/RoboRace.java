import RoboRace.*;
import javax.swing.*;
import COSC3P40.graphics.*;
import COSC3P40.sound.SoundManager;
import COSC3P40.xml.*;
import java.io.File;
import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.UnsupportedAudioFileException;

public class RoboRace {
    
    public static void main(String[] args) throws InvalidMidiDataException, IOException, MidiUnavailableException {
    	JFrame.setDefaultLookAndFeelDecorated(true);
        JDialog.setDefaultLookAndFeelDecorated(true);
	ImageManager.getInstance().setImagePath("./Images/");
	XMLReader.setXMLPath("./");
	XMLReader.setXSDPath("./XSD/");	
        NetworkPort np;
        String name=GameDialogs.showInputDialog("Players","Name of Player");
        Mysoundmanager mm=new Mysoundmanager();
        mm.playBGM();
        //String host=GameDialogs.showInputDialog("Players","IP of Player");
    	Socket socket=null;
        try{
            //while(true)
            //{
                try{
                    //if(host.equals("")){
                        socket=new Socket("localhost",998);
                       // break;
                   // }
                   // else{
                   //     socket=new Socket(host,998);
                   // }
                }catch(Exception e){}
            //}
            np=new NetworkPort(socket);
            np.send(name);
            new Player(name,np);
        }catch(Exception e){}
        
    }	   
}
